export class Book {

}

export const books = [];
